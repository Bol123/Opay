const menubtn = document.getElementById('menu');
const closebtn = document.getElementById('close');
const rightsec =  document.querySelector('.right-section')

const screenwidth = window.innerWidth

menubtn.addEventListener('click', () => {
   rightsec.classList.remove('active');
})

closebtn.addEventListener('click', () => {
   rightsec.classList.add('active');
 })




